#' A function for preparing the data.frame before the analysis
#'
#' This function takes as input a data.frame and the names of the 
#' variables in order check the variables and their r types.
#' 
#' @param A the data.frame with the variables to test.
#' @param var_y  the variable for the disease yes/not.
#' @param vars_cont  the name of the variables with continuous values.
#' @param vars_disc  the name of the variables with categorical values.
#' @param vars_int  the name of the variables with integer (ordered) values.
#' @param var_id  the name of the variable for the unique identifier per row.
#' 
#' @return
#' \describe{
#'   \item{A}{data.frame for the dataset}
#'   \item{var_disc_from_cont}{discretized variables from continuous ones}
#'   \item{vars_disc}{value from input parameter}
#'   \item{vars_cont}{value from input parameter}
#'   \item{var_y}{value from input parameter}
#' }
#' 
#' @keywords 
#' @export
#' @examples
#' 
#' data(DebTrivedi)
#' A         <- DebTrivedi[,c("age","ofp","gender","region","health")]
#' A$id      <- 1:nrow(A)
#' A$hospbin <- DebTrivedi$hosp>0
#' vars_cont <- c("age","ofp")
#' vars_disc <- c("gender","region","health")
#' var_id    <- "id"
#' var_y     <- "hospbin"
#' fp = data_prepare(A,var_y,vars_cont,vars_disc,var_id)
#' print(head(fp$A))
#' 
data_prepare <- function(A,var_y=NULL,vars_cont=NULL,vars_disc=NULL,vars_int=NULL,var_id=NULL) {#,discretize_=FALSE) {
  n0=nrow(A)
  p0=ncol(A)
  
  #string name with integer value at last character not allowed
  for (nv in names(A)) {stopifnot(!(substr(nv,nchar(nv),nchar(nv))%in%paste(0:9)));}
  
  if (!is.null(var_id)) {
    stopifnot(var_y%in%names(A))
    stopifnot(length(unique(A[,var_id]))==nrow(A))
  }
  
  if (!is.null(vars_int)) {
    stopifnot(sum(vars_int%in%names(A))>0)
    for (nv in vars_int) {
      var_     <- A[,nv]
      var_     <- as.integer(as.character(var_))
      A[,nv]   <- var_
    }
  }
  
  if (!is.null(vars_cont)) {
    stopifnot(sum(vars_cont%in%names(A))>0)
    for (nv in vars_cont) {
      var_     <- A[,nv]
      var_     <- as.numeric(as.character(var_))
      A[,nv]   <- var_
    }
  }
  
  # if (discretize_) {
  #   stopifnot(sum(vars_cont%in%names(A))>0)
  #   for (nv in vars_cont) {
  #     var_     <- A[,nv]
  #     var_     <- as.numeric(as.character(var_))
  #     D        <- data.frame(
  #       v2=as.character(Hmisc::cut2(var_,g = 2)), 
  #       v3=as.character(Hmisc::cut2(var_,g = 3)),
  #       v4=as.character(Hmisc::cut2(var_,g = 4)),
  #       v4=as.character(Hmisc::cut2(var_,g = 5)))
  #     names(D) <- paste(nv,"_",c(2,3,4,5),"cl",sep='')
  #     A        <- data.frame(A,data.frame(lapply(D, as.character), stringsAsFactors=FALSE))
  #   }
  # }
  #vars_disc = c(vars_disc,names(A)[(p0+1):ncol(A)])
  
  if (!is.null(vars_disc)) {
    stopifnot(sum(vars_cont%in%names(A))>0)
    for (nv in vars_disc) {
      var_     <- A[,nv]
      var_     <- as.character(as.character(var_))
      A[,nv]   <- var_
    }
  }
  A[,var_y]=as.character(A[,var_y])
  
  return(list(A=A,var_disc_from_cont=names(A)[(p0+1):ncol(A)],
         vars_disc=vars_disc,vars_cont=vars_cont,var_y=var_y))
}

