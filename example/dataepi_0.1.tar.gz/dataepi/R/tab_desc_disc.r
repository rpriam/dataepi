#' A function for describing the data.frame for the categorical variables
#'
#' This function take as input a data.frame and the names of the categorical 
#' variables in order to print in a table the names, frequencies per modalities,
#' percentable per modalities, and the number of levels and number of NA values.
#' 
#' @param A the data.frame with the variables to test.
#' @param vars_disc  the name of the variables with categorical values.
#' 
#' @return A data.frame with each row for a categorical variable and with the 
#' following columns: "variable name","number of NA", 
#' "number of levels per variable",
#' "number of observations per level",
#' "proportion of observations perlevel",
#' "name of level (or modalities)"
#' 
#' @keywords 
#' @export
#' @examples
#' data(DebTrivedi)
#' A         <- DebTrivedi
#' vars_disc <- c("health","gender","region")
#' TT        <- tab_desc_disc(A,vars_disc)
#' print(TT) 
#' 
tab_desc_disc <- function(A,vars_disc) {
  D=A[,names(A)%in%c(vars_disc)]
  p=ncol(D)
  TT  = data.frame(vars_disc,numeric(p),numeric(p),
                  character(p),character(p),character(p))
  TT[,4] = as.character(TT[,4])
  TT[,5] = as.character(TT[,5])
  TT[,6] = as.character(TT[,6])
  names(TT) <- c("var","nb_na", "nblevel","nbperlevel","propperlevel","namelevel")
  c = 0;
  for (nv_ in vars_disc) {
    c          = c+1;
    #cat("var=",nv_,"\n");
    TT[c,2] = sum(is.na(D[,nv_]))
    TT[c,3] = length(unique(D[!is.na(D[,nv_]),nv_]))
    ttnv    = table( sort(D[,nv_]) )
    TT[c,4] = paste(ttnv[ttnv>0],collapse=';')
    TT[c,5] = paste(round(ttnv[ttnv>0]/sum(ttnv[ttnv>0]),2),collapse=';')
    TT[c,6] = paste(as.character(unique( sort(D[!is.na(D[,nv_]),nv_]) )),collapse=';')
  }
  return(TT)
}
