round_all <- function(x) {
  return (round(x,2))
}

zero_all <- function() {
  return ("0.00")
}
