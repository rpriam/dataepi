#' A function for describing the data.frame for the continuous variables
#'
#' This function take as input a data.frame and the names of the continuous  
#' variables in order to print in a table the names, plus the median, mean,
#' standard-deviation, minimum, maximum, number of NA, and the number of not NA.
#' 
#' @param A the data.frame with the variables to test.
#' @param vars_cont  the name of the variables with continuous values.
#' 
#' @return A data.frame with each row for a continuous variable and with the 
#' following columns: "variable name ", "median", "mean", "standard-deviation", 
#' "minimum", "maximum","number of NA", "number of observation"
#' 
#' @keywords 
#' @export
#' @examples
#' data(DebTrivedi)
#' A         <- DebTrivedi
#' vars_cont <- c("age","ofp")
#' TT        <- tab_desc_cont(A,vars_cont)
#' print(TT) 
#' 
tab_desc_cont <- function(A,vars_cont) {
  D=A[,names(A)%in%vars_cont]
  if (length(vars_cont)==1) {D=data.frame(D); names(D)[1]<-vars_cont;}
  p=ncol(D)
  TT = data.frame(nom=vars_cont,matrix(0,nrow=p,7));
  names(TT) <- c("var", "median", "mean", "sd", "min", "max","nb_na", "nb")
  c = 0;
  for (nv_ in vars_cont) {
    c          = c+1;
    TT[c,2] = round( stats::median(D[,nv_],na.rm = TRUE), 2)
    TT[c,3] = round( base::mean(D[,nv_],na.rm = TRUE), 2)
    TT[c,4] = round( stats::sd(D[,nv_],na.rm = TRUE), 2)
    TT[c,5] = round( base::min(D[,nv_],na.rm = TRUE), 2)
    TT[c,6] = round( base::max(D[,nv_],na.rm = TRUE), 2)
    TT[c,7] = sum(is.na(D[,nv_]))
    TT[c,8] = sum(!is.na(D[,nv_]))
  }
  return(TT)
}
